package org.bukkit.event.player;
public class PlayerTeleportEvent extends PlayerMoveEvent { }
